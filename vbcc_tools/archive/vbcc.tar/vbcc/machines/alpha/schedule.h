
#define PIPES 4
#define REGS 64

